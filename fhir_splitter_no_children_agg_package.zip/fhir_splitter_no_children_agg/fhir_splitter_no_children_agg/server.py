
from fastapi import FastAPI, UploadFile, File
from fastapi.responses import HTMLResponse, JSONResponse, StreamingResponse
from .splitter import collect_resources_except_bundle, group_by_resource_type, ui_mapping, build_zip_bytes
import json

app = FastAPI()

@app.get("/", response_class=HTMLResponse)
def index():
    from pathlib import Path
    return HTMLResponse((Path(__file__).parent/"static"/"index.html").read_text(encoding="utf-8"))

@app.post("/analyze")
async def analyze(file: UploadFile = File(...)):
    data = json.loads((await file.read()).decode("utf-8"))
    grouped = group_by_resource_type(collect_resources_except_bundle(data, []))
    return JSONResponse(ui_mapping(grouped))

@app.post("/download")
async def download(file: UploadFile = File(...)):
    data = json.loads((await file.read()).decode("utf-8"))
    grouped = group_by_resource_type(collect_resources_except_bundle(data, []))
    blob = build_zip_bytes(grouped)
    return StreamingResponse(iter([blob]), media_type="application/zip",
                             headers={"Content-Disposition": "attachment; filename=Output.zip"})
